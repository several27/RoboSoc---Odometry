//
// Created by Maciej Szpakowski on 13/11/15.
//

#include <Arduino.h>
#include "Robot.h"

Robot::Robot() { }
Robot::~Robot() { }

void Robot::setup(Wheel* leftWheel, Wheel* rightWheel)
{
	this->leftWheel = leftWheel;
	this->rightWheel = rightWheel;
}

void Robot::move(Wheel::MoveDirection direction)
{
	this->leftWheel->move(direction, this->normalSpeed);
	this->rightWheel->move(direction, this->normalSpeed);
}

void Robot::moveForward()
{
	this->move(Wheel::FORWARD);
}

void Robot::moveBackward()
{
	this->move(Wheel::BACKWARD);
}

void Robot::moveFor(uint16_t steps, Wheel::MoveDirection direction)
{
	this->move(direction);
	
	while (steps > 0)
	{
		steps -= this->rightWheel->getDistance();
		this->rightWheel->updateDistance();
	}
}

// (uint16_t) angle is an angle of a circle to follow
// (uint32_t) radius of a bigger circle that is followed by the firstWheel
// secondWheel follows the smaller circle which is calculated
// by substracting width of an robot from bigger radius
void Robot::followCircle(uint16_t angle, uint32_t radius, Wheel* firstWheel, Wheel* secondWheel)
{
	uint16_t stepsOfFirstCircle = 2 * PI * (radius - this->width) * ( angle / 360 );
	uint16_t stepsOfSecondCircle = 2 * PI * radius * ( angle / 360 );
	
	uint8_t firstWheelSpeed = (stepsOfSecondCircle * this->normalSpeed) / stepsOfFirstCircle;
	
	firstWheel->move(this->normalSpeed);
	secondWheel->move(stepsOfFirstCircle);
	
	while (stepsOfSecondCircle > 0)
	{
		stepsOfSecondCircle -= secondWheel->getDistance();
		secondWheel->updateDistance();
	}
}

// follows a circle in the right direction, bigger distance will be driven
// by the left wheel
void Robot::followCircleInRight(uint16_t angle, uint32_t radius)
{
	this->followCircle(angle, radius, this->rightWheel, this->leftWheel);
}

// follows a circle in the left direction, bigger distance will be driven
// by the right wheel
void Robot::followCircleInLeft(uint16_t angle, uint32_t radius)
{
	this->followCircle(angle, radius, this->leftWheel, this->rightWheel);
}

// Moves the firstWheel and stops the secondWheel
// as long as angle is reached
void Robot::turn(uint16_t angle, Wheel* firstWheel, Wheel* secondWheel)
{
	uint16_t steps = 2 * PI * this->width * ( angle / 360 );
	firstWheel->move(this->normalSpeed);
	secondWheel->stop();
	
	while (steps > 0)
	{
		steps -= firstWheel->getDistance();
		firstWheel->updateDistance();
	}
}

void Robot::turnRight(uint16_t angle)
{
	this->turn(angle, this->rightWheel, this->leftWheel);
}

void Robot::turnLeft(uint16_t angle)
{
	this->turn(angle, this->leftWheel, this->rightWheel);
}